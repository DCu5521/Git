# Python code to add two numbers
def add(a,b):
   return a + b

print("The addition of 12  and 31 is: ", add(12,31))

# Python code for subtraction
def subtract(a,b):
   return a - b
print("The subtraction of 55 and 45 is: ", subtract(55,45))

# Python code for multiplication
def multiply(a,b):
   return a * b
print("The multiplication of 95 and 8 is: ", multiply(95,8))

# Python code for division
def divide(a,b):
   return a / b
print("The division of 56 and 7 is: ", divide(56,7))
